document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.getElementById("sidebar");
    const menuButton = document.querySelector(".bx-menu");
    const searchForm = document.getElementById("search-form");
    const parcelIdInput = document.getElementById("parcel-id");
    const boxInfo = document.getElementById("box-info");
    const orderTableBody = document.getElementById("order-table-body");
    const noMatchFound = document.getElementById("no-match-found");

    // Add event listener to the menu button to toggle the sidebar
    menuButton.addEventListener("click", function (e) {
        e.stopPropagation(); // Prevent the click event from propagating to the document click event
        sidebar.classList.toggle("active");
    });

    // Add event listener to close the sidebar when clicking outside of it
    document.addEventListener("click", function (event) {
        if (!sidebar.contains(event.target) && event.target !== menuButton) {
            sidebar.classList.remove("active");
        }
    });

    // Add event listener to search form
    searchForm.addEventListener("submit", function (e) {
        e.preventDefault();
        const parcelId = parcelIdInput.value.trim();

        // Clear previous search results
        orderTableBody.innerHTML = "";
        noMatchFound.style.display = "none";

        if (parcelId) {
            // Simulate fetching parcel details from the database
            // In a real application, you would fetch data from your database
            // and then update the table with the fetched data.
            // Here, we are adding a single record for demonstration purposes.
            const record = {
                parcelId: "985vy6npt95bqv tb",
                parcelName: "John Doe",
                dateOrder: "01-10-2021",
                status: "Completed",
            };

            // Check if the entered parcelId matches the fetched record
            if (parcelId === record.parcelId) {
                // Display the matching record in the table
                const newRow = document.createElement("tr");
                newRow.dataset.parcelId = record.parcelId;
                newRow.innerHTML = `
                    <td>${record.parcelId}</td>
                    <td><p>${record.parcelName}</p></td>
                    <td>${record.dateOrder}</td>
                    <td><span class="status completed">${record.status}</span></td>
                `;
                orderTableBody.appendChild(newRow);
            } else {
                // Display "No match found" message
                noMatchFound.style.display = "block";
            }
        }
    });

    // Add event listener to "New Order" and "Track" boxes
    boxInfo.addEventListener("click", function (e) {
        const target = e.target.closest("li");
        if (target) {
            const link = target.dataset.link;
            if (link) {
                // Redirect to the specified link
                window.location.href = link;
            }
        }
    });

    // Add event listener to order table rows
    orderTableBody.addEventListener("click", function (e) {
        const target = e.target;
        if (target.tagName === "TD") {
            // Get the parcel ID from the data attribute
            const parcelId = target.parentElement.dataset.parcelId;
            if (parcelId) {
                // Redirect to the parcel tracking page using parcelId
                window.location.href = `/track/${parcelId}`;
            }
        }
    });
});
